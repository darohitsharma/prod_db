#!/usr/bin/env python3
"""Copy ONLY generic browser assets to docs/. Never copies data or credentials."""
from pathlib import Path
import shutil
ROOT=Path(__file__).resolve().parent
out=ROOT/'docs';out.mkdir(exist_ok=True)
allowed=['index.html','style.css','core.js','app.js','config.js']
for name in allowed:shutil.copy2(ROOT/'web'/name,out/name)
(out/'.nojekyll').write_text('')
extra={p.name for p in out.iterdir()}-set(allowed)-{'.nojekyll'}
if extra:raise SystemExit('Unexpected docs files: '+str(extra)+'. Inspect before publishing.')
print('Pages folder ready: docs/ (generic code only, no production rows)')

# A single-file browser-upload option for GitHub Pages root.
standalone=(ROOT/'web/index.html').read_text()
standalone=standalone.replace('<link rel="stylesheet" href="style.css">','<style>'+ (ROOT/'web/style.css').read_text()+'</style>')
for name in ['config.js','core.js','app.js']:
    standalone=standalone.replace('<script src="'+name+'"></script>','<script>'+ (ROOT/'web'/name).read_text()+'</script>')
(ROOT/'publish').mkdir(exist_ok=True)
(ROOT/'publish/index.html').write_text(standalone)
print('Browser-upload option ready: publish/index.html (no data)')
