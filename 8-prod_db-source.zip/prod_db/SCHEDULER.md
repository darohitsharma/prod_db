# Scheduler handoff

Part 1 uses the earlier GitHub Pages dashboard process: Google sign-in, then a manual read-only refresh. There is no background Actions job, cron task, email, external monitor or scheduled run configured here.

The UI data hook is `readLive()` in web/app.js. It fetches the two Sheets with the current tab's short-lived Google read-only token and replaces data only when the read succeeds. A real unattended scheduler cannot rely on that tab token: it expires and the browser may be closed.

Before adding automation, confirm the intended old scheduler, its cadence, where it runs and how it stores credentials privately. Keep business data out of public GitHub Actions artifacts, logs and repositories. A workflow that publishes data to Pages would leak it and is not included.
