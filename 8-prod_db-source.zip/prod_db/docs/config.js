window.PROD_CONFIG = {
  "clientId": "708358954866-8vauri7omd6ed9il9ebekogcp5gn4qf7.apps.googleusercontent.com",
  "sources": [
    {
      "label": "GP 44",
      "id": "1SzJvNuVGtjzvPoOgOyDa6q8ZFqvu79oD89i_-JLb93s"
    },
    {
      "label": "GP-26",
      "id": "1NZgXpBJE4wuTT0FAPewpgCvgKquMPCX_HY_FctrA1a8"
    }
  ]
};
