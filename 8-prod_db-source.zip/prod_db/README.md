# prod_db - Production yield dashboard

Read-only browser dashboard for two private Google Sheets. Neutral theme with a green accent. Works locally and on free GitHub Pages. No backend, database, paid hosting, API key or npm install is required. Python 3 is used only to serve local files.

## Start in VS Code (Mac)

1. Unzip the complete prod_db folder. Keep this separate from the older cs-dashboard project.
2. VS Code > File > Open Folder > choose prod_db. Open Terminal > New Terminal.
3. Run `python3 --version`. If Python is missing, install Python 3 from python.org, reopen VS Code, then retry.
4. Run `python3 server.py`. Your browser opens `http://localhost:5173/web/`.
5. The privately supplied saved snapshot opens immediately. It is NOT live and is labeled with its read time. A public clone has no snapshot: connect Google instead.
6. Click **Connect Google**, choose the work account that has access to BOTH source Sheets, and approve read-only Sheets access. Sign-in may ask for Google's normal verification. The website cannot bypass that.
7. After Sheets change, click **Refresh from Sheets**. This is the same manual-refresh process as the original GitHub Pages dashboard, not a background scheduler.
8. Stop with Ctrl+C in Terminal. If port 5173 is busy, use `python3 server.py --port 5174` and add that localhost origin in the Google OAuth configuration if needed.

## Filters and numbers

- Source at top: All / GP 44 / GP-26.
- From and To are inclusive and apply together with Month, Category and Search.
- DoD is day-wise grouping. MoM is month-wise grouping, with an All or individual month selector. Neither claims a previous-period growth calculation.
- Search matches date, source, category, SKU and product name.
- Detail table has all requested columns and a source/check column. Long tables scroll sideways and have 40-row pages. CSV includes all currently filtered rows, not just the visible page.
- Yield is Receive / Make as a ratio to 2 decimals. Totals use SUM(Receive) / SUM(Make) over rows with positive Make and a known non-negative Receive. Missing quantities are unknown, not zero. Known totals are summed independently, so a partial-data total ratio may differ from the valid-row weighted yield. Incomplete counts are visible.
- Values over 1.00 are preserved and flagged, not capped. Source Sheets are never changed.
- Read monthly production tabs only. New monthly tabs are discovered by their month/year names. Historical daily tabs and Pending Reports are excluded to avoid overlap. Month tabs are not deduplicated: separate source rows may be legitimate batches. Row dates determine filtering, including unusual dates outside their tab month. Data checks flag quantity issues; source date corrections are left to the owner.

## Put it live on GitHub Pages (free)

Use only the generic code. The optional `data/` folder is company data: NEVER upload it, even as an initial commit. It is in .gitignore, but GitHub browser uploads ignore .gitignore rules, so choose files carefully.

1. Sign in to your personal GitHub account. Create a NEW repository called `prod_db`. Public generic code is needed for the same free Pages approach. Do not delete or replace an existing repository.
2. Locally run `python3 prepare_pages.py`. This builds `docs/` from a fixed allowlist. It never copies data.
3. Commit only `web/`, `docs/`, `tests/`, `.gitignore`, `README.md`, `server.py`, `prepare_pages.py` and `SCHEDULER.md`. Do not commit the snapshot, tokens, credentials or personal screenshots.
4. In the new repository: Settings > Pages > Deploy from a branch > main > /docs > Save.
5. Wait for GitHub's Pages deployment to finish. Use the actual website link shown in Pages settings. Do not guess a deployment URL or treat a queued build as published.
6. Open it. Before Google sign-in, no production rows should appear. Connect Google and verify both sources, filters and totals.
7. Test a source change by refreshing, then restore any deliberate test edits yourself. The dashboard never writes to Sheets.

Public exposure: generic UI, source code, Sheet identifiers and OAuth client identifier. Private: production rows, Google access tokens, local snapshot. Tokens live only in the current tab's memory, not localStorage, GitHub or this project. A user can see data only after Google authorizes a token and their Google account can read the Sheets. The generic public page itself is NOT owner-only. Do not confuse a sign-in hint with an access restriction; Google Sheet permissions enforce data access.

## Google setup / common problems

The existing public browser OAuth client from the earlier cs-dashboard is reused in `web/config.js`. Both Pages projects use the same scheme+host origin, so a new repository path does not normally require a new origin. The localhost:5173 origin has been checked and reaches normal Google sign-in. It still requires account authorization; origin acceptance alone is not proof of a successful Sheet read.

- `origin_mismatch`: in Google Cloud Console, open the existing project's web OAuth client and add the exact origin printed by the browser (scheme, hostname, optional port, NO path). For local use, usually `http://localhost:5173`. For Pages, use the Pages site's exact HTTPS origin. Do not create/print a client secret for a browser app.
- `access_denied` / testing mode: allow the intended work account in the OAuth app's test users, or ask your Workspace admin. Do not make private Sheets link-accessible as a workaround.
- API disabled: enable Google Sheets API for that existing Google Cloud project. Do not enable billing or enter a card.
- 403: check account access to both Sheets and Sheets API enablement. Failed refresh keeps the previous in-memory data.
- Popup blocked: allow the Google sign-in popup and click Connect Google again.
- Token expired: reconnect. Tokens are deliberately not saved between sessions.
- Blank local page: use the server URL, not a file:// URL, and keep the terminal running.

## Edit / maintain without assistance

- `web/index.html`: labels and layout. `web/style.css`: light/dark theme. `web/core.js`: parsing, filters, summaries. `web/app.js`: Google read, controls, chart, CSV. `web/config.js`: public IDs only.
- `data/snapshot.json`: optional PRIVATE normalized checked data, never a live connector.
- `node tests/core.test.js`: optional calculation tests (Node.js required only for tests). No npm packages required.
- After code changes: rerun tests, run locally, inspect light/dark and mobile, run prepare_pages.py, commit/push generic files. GitHub Pages redeploys code after push. Pushing code is not a data refresh.
- Change both `web/` and the generated `docs/` via prepare_pages.py. Do not edit only docs, because the next prepare overwrites it.
- Back up your private local data separately. Never commit credentials. No paid services are configured by this project.

## Fast browser-upload deployment alternative

prepare_pages.py also makes publish/index.html, a complete generic single-file app. When using GitHub's browser upload, upload just this index.html at the new repository root, then choose main / (root) in Pages. Do not upload the whole project folder. The app file contains readable CSS/JS and public IDs, never production rows or credentials. For later edits, use the modular web/ files, rerun prepare_pages.py, and replace the root index.html with the newly generated publish/index.html. The optional sanitized source ZIP can be kept in the repository for VS Code editing; it has no data directory.
