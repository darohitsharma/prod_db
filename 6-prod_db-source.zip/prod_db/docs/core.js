/* Pure calculations shared by the browser and Apps Script. */
(function(root){
  function dateISO(v){
    if(typeof v==='number' && isFinite(v)) return new Date(Date.UTC(1899,11,30)+Math.round(v)*86400000).toISOString().slice(0,10);
    if(v instanceof Date && !isNaN(v)) return v.toISOString().slice(0,10);
    let s=String(v??'').trim(); if(!s)return null;
    if(/^\d{4}-\d\d-\d\d/.test(s))s=s.slice(0,10);
    else {let m=s.match(/^(\d{1,2})[-/ ]([A-Za-z]+|\d{1,2})[-/ ](\d{2}|\d{4})$/);if(!m)return null;
      let months=['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
      let mo=/^\d+$/.test(m[2])?+m[2]:months.indexOf(m[2].slice(0,3).toLowerCase())+1;
      s=(m[3].length===2?'20'+m[3]:m[3])+'-'+String(mo).padStart(2,'0')+'-'+m[1].padStart(2,'0');
    }
    let d=new Date(s+'T00:00:00Z');return !isNaN(d)&&d.toISOString().slice(0,10)===s?s:null;
  }
  function num(x){if(x===null||x===undefined||String(x).trim()==='')return null;let n=Number(String(x).replace(/,/g,''));return Number.isFinite(n)?n:null;}
  function normalize(tabs){let rows=[],issues=[];
    for(let t of tabs){let grid=t.values;if(!grid||!grid.length)continue;let h=grid[0].map(x=>String(x??'').trim().toLowerCase().replace(/[^a-z0-9]/g,''));
      let ix=(names)=>h.findIndex(x=>names.includes(x));let map={date:ix(['date']),category:ix(['category']),sku:ix(['sku']),product:ix(['productname']),make:ix(['makeqty']),receive:ix(['receiveqty'])};
      if(map.date<0&&String(grid[0][0]??'').trim()==='')map.date=0;
      if(Object.values(map).some(x=>x<0))throw new Error('Unrecognized columns in '+t.site+' / '+t.tab);
      grid.slice(1).forEach((r,k)=>{if(!r.some(x=>String(x??'').trim()))return;let sku=String(r[map.sku]??'').trim();if(!sku||sku.toLowerCase()==='sku')return;
        let date=dateISO(r[map.date]);if(!date){issues.push(t.site+' / '+t.tab+' row '+(k+2)+': invalid date');return;}
        let make=num(r[map.make]),receive=num(r[map.receive]);
        let flags=[];if(make===null||receive===null)flags.push('Incomplete quantities');if(make===0)flags.push('Zero make quantity');if(make<0||receive<0)flags.push('Negative quantity');if(receive!==null&&make!==null&&receive>make)flags.push('Receive above make');
        rows.push({date,site:t.site,category:String(r[map.category]??'').trim(),sku,product:String(r[map.product]??'').trim(),make,receive,yield:make>0&&receive!==null&&receive>=0?receive/make:null,flags,tab:t.tab,row:k+2});
      });
    }return {rows,issues};
  }
  function filter(rows,f){let q=(f.search||'').toLowerCase().trim();return rows.filter(r=>(!f.site||f.site==='All'||r.site===f.site)&&(!f.from||r.date>=f.from)&&(!f.to||r.date<=f.to)&&(!f.month||f.month==='All'||r.date.slice(0,7)===f.month)&&(!f.category||f.category==='All'||r.category===f.category)&&(!q||[r.date,r.site,r.category,r.sku,r.product].join(' ').toLowerCase().includes(q)));}
  function summary(rows){let valid=rows.filter(r=>r.yield!==null),den=valid.reduce((s,r)=>s+r.make,0),rec=valid.reduce((s,r)=>s+r.receive,0);return {make:rows.reduce((s,r)=>s+(r.make??0),0),receive:rows.reduce((s,r)=>s+(r.receive??0),0),yield:den?rec/den:null,records:rows.length,incomplete:rows.filter(r=>r.make===null||r.receive===null).length,flagged:rows.filter(r=>r.flags.length).length,validRows:valid.length};}
  function group(rows,mode){let g={};for(let r of rows){let k=mode==='month'?r.date.slice(0,7):r.date;(g[k]??=[]).push(r);}return Object.keys(g).sort().map(k=>({period:k,...summary(g[k])}));}
  const api={dateISO,num,normalize,filter,summary,group};root.YieldCore=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
